/*
**  File:        queue.h
**  Program:     Sensor 
**  Purpose:     Class MessageQueue    
**  Author:      Michele Garetto
**  Last Update: January 10 2002
*/

#ifndef queue_h
#define queue_h

#include "message.h"

class MessageQueue {

public:

	MessageQueue() : head_(0), tail_(0), len_(0) {}
	virtual int length() const { return (len_); }
	virtual void enque(Message* s) {
		if (!tail_) head_= tail_= s;
		else {
			tail_->next_= s;
			tail_= s;
		}
		tail_->next_= 0;
		++len_;
	}
	virtual Message* deque() {
		if (!head_) return 0;
		Message* s = head_;
		head_= s->next_; // 0 if s == tail_
		if (s == tail_) head_= tail_= 0;
		--len_;
		return s;
	}
	Message* lookup(int n) {
		for (Message* s = head_; s != 0; s = s->next_) {
			if (--n < 0)
				return (s);
		}
		return (0);
	}
	
	/* remove a specific message, which must be in the queue */
	virtual void remove(Message*);
	
	/* Remove a message, located after a given message. Either could be 0. */
	void remove(Message *, Message *);
        Message* head() { return head_; }
	Message* tail() { return tail_; }
	
	virtual inline void enqueHead(Message* s) {
	        if (!head_) tail_ = s;
	        s->next_ = head_;
		head_ = s;
		++len_;
	}
        void resetIterator() { iter = head_;}
        Message* getNext() { 
	        if (!iter) return 0;
		Message *tmp = iter; iter = iter->next_;
		return tmp;
	}

protected:
	Message* head_;
	Message* tail_;
	int len_;		// message count
	
private:
	Message *iter;
};

#endif
