/*
**  File:        message.h
**  Program:     Sensor 
**  Purpose:     Class Message    
**  Author:      Michele Garetto
**  Last Update: January 10 2002
*/

#ifndef message_h
#define message_h

#include <assert.h>

class Sensor;
class Message {

public:
	
	Message() {}
	
	inline long& stepstart() { return (stepstart_); }
	inline long& stepend() { return (stepend_); }
	inline int& nhops() { return (nhops_); }
	inline double& energy() { return (energy_); }
	inline Sensor* source() { return (source_); }
		
	static inline Message* alloc(Sensor* source);
	static inline void free(Message*);
	
	Message* next_;		// for queues and the free list

protected:

	static Message* free_;	// message free list
	
private:

	long stepstart_; // time step at which the message is generated
	long stepend_;   // time step at which the message arrives at the sink
	int nhops_;      // number of intermediate sensors traversed 
			 // (except source and sink)
	double energy_;  // energy required to send/receive the message
	Sensor* source_; // pointer to source Sensor 
};

inline Message* Message::alloc(Sensor* source)
{
	Message* s = free_;
	if (s != 0) {
		free_ = s->next_;
	} else {
		s = new Message;
		assert(s != 0);
	}
	s->source_ = source;
	s->stepstart_ = 0;
	s->stepend_ = 0;
	s->nhops_ = 0;
	s->energy_ = 0.;
	s->next_ = 0;
	return (s);
}

inline void Message::free(Message* s)
{
	s->next_ = free_;
	free_ = s;
}

#endif
