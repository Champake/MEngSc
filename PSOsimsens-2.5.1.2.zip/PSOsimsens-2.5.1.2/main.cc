/*
**  File:        main.cc
**  Program:     Sensor
**  Purpose:     Modeling and simulation of a wireless sensor network
**  Version:     5.0
**  Author:      Michele Garetto / Dario Panno
**  Last Update: January 21 2003
**  Requires:    gsl library (gnu scientific library)
**  Last Edited: 21 September 2005
**  Edited:	 Champake Mendis
**
**  Note: 	 Linked with PSO
**  		 This uses a line Centre & a point
*/

#include <stdio.h>

#include "sensor.h"
#include "topology.h"
#include "service.h"
#include "simulation.h"
#include "message.h"
#include "queue.h"
#define MAXMOVE 50

/* definition of the Random Number Generator */
gsl_rng* RNG::rng_ = gsl_rng_alloc(gsl_rng_mt19937);	 /* MT19937 Matsumoto, Nishimura */

Message* Message::free_ = 0;	// initialize list of free messages

int pso_main (char *pso_in);
double uom_throughput,uom_Energy,uom_distance;
int topology_done=0, Ftop=0;
int Routing_Penalty;
double uom_topology[600][3];
double x,y;
Topology* topol = new Topology();
Simulation* sim = new Simulation(topol);

int main(int argc, char *argv[])
{	
int i;
FILE *topo;

	printf("\nTOTAL PROCESS STARTED !\n");	
	RNG::inputseed(); 
	topol->inputparameters();
	sim->inputparameters();

	// Keep topology consistent
/*	if ((topo==fopen("\\topo.run","rt"))!=NULL)
	{			
	printf("Read Sensor Topology from topo.run!\n");
		for (i=0;i<topol->nsens_;i++)
		{fscanf(topo,"%f %f",&x,&y);
		uom_topology[i][1]=x;
		uom_topology[i][2]=y; // X,Y Coordinate
		}
	fclose(topo);
	topology_done=1;
	} 
	else
	printf("File topo.run can not be opened !\n");*/
	

//	Deriving the optimum position in the periphery of field
	printf("\nPSO PROCESS STARTED !");	
	pso_main("pso.run");

 
	printf("\nTOTAL PROCESS ENDED !");	
	return 0;
}
