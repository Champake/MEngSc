/*
**  File:        sensor.h
**  Program:     Sensor 
**  Purpose:     Class Sensor    
**  Author:      Michele Garetto
**  Last Update: November 11 2002
*/

#ifndef sensor_h
#define sensor_h

#include <math.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>

#include "queue.h"	
#include "message.h"
#include "service.h"		

class Sensor;
typedef struct route {
	Sensor * N_;	      /* next hop Sensor */
	double E_;	      /* minimum energy necessary to reach the sink */
	struct route* next_;  /* next route in the list maintained by the sensor */
	struct route* prec_;  /* prec route in the list maintained by the sensor */
	unsigned long ntx_;   /* number of times this route has been used */
} Route;

enum SENSORSTATE { SLEEP, ACTIVE_IDLE, ACTIVE_TX, ACTIVE_RX, DROWSY_IDLE, DROWSY_TX };

class Sensor {
friend class Topology;
friend class Simulation;
public:

	Sensor(Topology* t); 
	Sensor(Topology* t, double x, double y);
	Sensor(Topology* t, double x, double y, double pSI, double pIS);
	
	inline double& x() { return (x_); }
	inline double& y() { return (y_); }
	inline double& pSI() { return (pSI_); }
	inline double& pIS() { return (pIS_); }
	inline double& dist() { return (dist_); }
	inline int& flood() { return (flood_); }
	inline int& nroutes() { return (nroutes_); }
	inline int& isolated() { return (isolated_); }
	inline unsigned long& id() { return (id_); }
	inline int& state() { return (state_); }
	
	inline double& lambda() { return (lambda_); }
	inline double& pI() { return (pI_); }
	inline double& pS() { return (pS_); }
	inline int& tauI() { return(tauI_); }
	inline int& tauS() { return(tauS_); }
	inline int& nr() { return (nr_); }
	inline int& could_TX() { return (could_TX_); }
	inline int& could_RX() { return (could_RX_); }
	
	inline unsigned long& msgRX() { return (msgRX_); }
	inline unsigned long& msgTX() { return (msgTX_); }
	inline unsigned long& msgLOST() { return (msgLOST_); }
	inline unsigned long& msgGEN() { return (msgGEN_); }
	inline unsigned long& msgDEL() { return (msgDEL_); }
	
	inline MessageQueue* q() {return(q_);} 
	
	virtual void init();
	virtual void resetstat();
	void alloc();
	
	virtual void evolve(unsigned long step);
	virtual void operate(unsigned long step);
	virtual void receive(Message* s, Sensor* from, unsigned long step); 
	virtual void updatestat(unsigned long step);
	
	double bestE() { if(firstr_) return(firstr_->E_); else return(-1.); }
	double worstE() { return(lastr_->E_); }
	Sensor* nexthop() { return(firstr_->N_); }
	double distance(Sensor*);
	
	void update(Sensor*, double);
	int insertroute(Sensor*, double);
	void printroutes();
	void computestat(unsigned long steps);

	void delivered(Message *m); 	

	Sensor* next_;	            /* next Sensor in the list of all sensors */
	unsigned long* qlf_;        /* queue length frequencies */	
	unsigned long* sf_;         /* state frequencies */
	unsigned long* complf_;	    /* completion times frequencies for arrived messages */
	unsigned long  sumcompl_;   /* sum of completion times for arrived messages */
	unsigned long  sumhops_;    /* sum of hops for arrived messages */
	unsigned long* hopf_;	    /* traversed hops frequencies for arrived messages */
	double msgenergy_;          /* sum of energy spent to transfer the messages arrived at the sink */
	
	MessageQueue* q_; /* underlying FIFO queue */  
	
	unsigned long alphaf_,sumalpha_;       /* to compute parameter alpha_ */
	unsigned long alpha1f_,sumalpha1_;     /* to compute parameter alpha1_ */
	unsigned long betaf_,sumbeta_;         /* to compute parameter beta_ */
	unsigned long sumbetacond_;	       /* to compute conditional interferers */
	unsigned long beta1f_,sumbeta1_;       /* to compute parameter beta1_ */
	unsigned long buftsum_,buftnum_;       /* to compute average buffer size at transition R->N */
	double avebuft_;		       /* average buffer size at transition R->N */
	
	int executed_;
	
protected:

	unsigned long id_;	/* identification number */
	double x_; 	/* x coordinate (meters) */
	double y_;      /* y coordinate (meters) */
	double dist_;   /* distance from the sink */
	
	double pSI_;    /* transition probability SLEEP -> IDLE */
	double pIS_;    /* transition probability IDLE -> SLEEP */
	double pS_;     /* stationary SLEEP probability */
	double pI_;     /* stationary IDLE probabiltity */
	int tauI_;      /* steps in IDLE state */
 	int tauS_;      /* steps in SLEEP state */
	
	Topology* t_;     /* Topology this sensor belongs to */
	int state_;       /* one of SENSORSTATE */
	int isolated_;  
	
	unsigned long hasTXto_;	  /* set during the step to the index of the sensor target of a TX, if any (or -1) */
	
	unsigned int nextarrival_; 	/* next arrival time */
	double lambda_;			/* arrival rate of new messages (per step) */
	
	int could_RX_;		/* whether sensor could receive during this step */
	int could_TX_;		/* whether sensor could transmit during this step */
	int wantTX_;		/* whether sensor wants to transmit at the beginning of the step */
	
	unsigned long msgRX_;    /* number of messages received */
	unsigned long msgTX_;    /* number of messages sent */
	unsigned long msgLOST_;  /* number of messages lost */
	unsigned long msgGEN_;   /* number of messages generated */
	unsigned long msgDEL_;   /* number of messages delivered to the sink */

	Route* firstr_;  /* first route of the list */
	Route* lastr_;   /* last route of the list */
	int nr_;         /* number of routes in the list */ 
	int flood_;      /* flag indicating the sensor needs to flood its best route */
	int nroutes_;    /* number of alternate routes maintained by each sensor */
	
	/* final statistics */
	double pi_state_[NUMSTATE], pi_active;
	double avecompl,avehops,avetxrx,aveerate,avebuf,aveetxrx,aveetran;
	double lambda_e,lambda_i,lambda_o;
	double alfa,alfa1,beta,beta1,avebeta,avealfa;
	double pisleep_, piactiveR_, piactiveN_;
	double piR0_; 
	
};	

class Sink : public Sensor {

public:

	Sink(Topology* t) : Sensor(t) {}
        Sink(Topology* t, double x, double y) : Sensor(t,x,y) {}
	Sink(Topology* t, double x, double y, double pSI, double pIS) : Sensor(t,x,y,pSI,pIS) {}
	
	void init();
	void receive(Message* s, Sensor* from, unsigned long step);
	void evolve(unsigned long step) { state_ = ACTIVE_IDLE; could_RX_ = 1; } 
	void operate(unsigned long step) {} /* do nothing */
};

#endif
