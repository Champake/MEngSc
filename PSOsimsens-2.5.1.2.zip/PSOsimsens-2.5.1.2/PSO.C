/*
  This program optimizes five benchmark functions using swarm algorithm
  Asynchronous version 
  Yuhui Shi, May 15, 1998
**  Last Edited: 12th June 2006
**  Edited:	 Champake Mendis
**
**  Note: 	 Linked with PSO
**  		 This uses a Distance as the
**		 objective function
** 		 This is modified to use 
** 		 SIMSENS for optimizing
**  
*/

#include "headfile.h"
#include "global.h"
#include "mem_loc.h"
#include "myfun.h"
#include "sensor.h"
#include "topology.h"
#include "service.h"
#include "simulation.h"
#include "message.h"
#include "queue.h"



//int c_break(void);


/* ******************** main() ******************** */
int pso_main (char *pso_in)
{
  const int nsen=180;
  extern int Routing_Penalty;
  extern double uom_distance;
  double dRandom,dRandom2;
  long int step=10e6;

  extern Topology* topol;
  extern Simulation* sim;

  int  NUMBER_OF_AGENTS;

  float E_CUTOFF,  MAXV, MAXX;

  float weight, weight_up;
  int  MAXITER;
  int run_no;  //number of runs

  FILE *fp, *frun;
  char runfile[60], resfile[60];
  char temp[10];
  char tempfile[60];

  float minval=0.0;
  int DIMENSION;
  int fun_type;	//0:Schaffer f6	1:sphere		2:Rosenbrock	3:generalized Rastrigrin
						//4:generalized Griewank
  float IRang_L, IRang_R;  // initialization rang: left and right range
  double sink_theta_, sink_theta2_,sink_theta3_,sink_R,iSAngle;
  int a,b;

  int i;

  int iter;
  int gbest;
  int firsttime;
  int tmp,finish;

  time_t tt;
// New Parameters
double TOT_distance=0.0;
double d,dtimes;
double m;
double sink_x1,sink_y1,sink_x2,sink_y2,sink_x3,sink_y3,
       sink_tempx1,sink_tempx2,sink_tempx3;
double pbestx1[nsen],pbestx2[nsen],pbesty1[nsen],pbesty2[nsen],
       pbestx3[nsen],pbesty3[nsen];


	/* *********************************************************
		Open runfile
	********************************************************* */
/*	if (argc<2)
	{
		printf("Need to specify runfile. For Example: pso pso.run");
		exit(1);
	} */

	strcpy(runfile,pso_in);

	if ((frun=fopen(runfile,"r"))==NULL)
	{
		printf("Cant read file");
		exit(1);
	}

	/*                N  G  S  E  V  X  M  U  Res */
	fscanf(frun, "%d  %f  %f %f %f %f  %d  %s %f %d %d %d",
	 &NUMBER_OF_AGENTS,  &E_CUTOFF,
	 &MAXV, &MAXX,&IRang_L,&IRang_R, &MAXITER,  tempfile,
	 &weight, &fun_type,&DIMENSION,&run_no);
	fclose(frun);

	FVectorAllocate(&pbest,            NUMBER_OF_AGENTS);
	FVectorAllocate(&maxx,             DIMENSION);
	FMatrixAllocate(&vx,     DIMENSION,NUMBER_OF_AGENTS);
	FMatrixAllocate(&xx,     DIMENSION,NUMBER_OF_AGENTS);
	FMatrixAllocate(&tx,     DIMENSION,NUMBER_OF_AGENTS);
	FMatrixAllocate(&pbestx, DIMENSION,NUMBER_OF_AGENTS);

	for (a=0;a<DIMENSION;a++)
	{
		maxx[a]=MAXX;          /* range of xx[]  */
	}

	time(&tt);
	printf("\nPSO begin time: %s\n",ctime(&tt));

	//loop for runs
	for (i=0;i<run_no;i++)
	{
		firsttime=1;           //first iteration of this run
		iter=0;
		gbest=0;               //initialy assume the first particle as the gbest

		 /* **********************************************
			This loop initializes the individual agents  for each run
		********************************************** */
		iSAngle=360/DIMENSION; sink_theta_ = 0;

		for (a=0;a<NUMBER_OF_AGENTS;a++)
		{
			for (b=0;b<DIMENSION;b++)
			{       
				xx[b][a] = sink_theta_*360/(2*PI);
				pbestx[b][a] = xx[b][a];
				dRandom=(rand()%step)/step;
				vx[b][a] = MAXV*dRandom;
				dRandom=(rand()%step)/step;
				if (dRandom > 0.5) vx[b][a]=-vx[b][a];
				sink_theta_+=iSAngle;	
				
			}
		}
		/* *******************************************************
			Main Work Loop for each run here
		******************************************************** */

		/********************************************************
			get the output result file name
		**********************************************************/
		if (i>=10)
		{
			int temdec=i/10;
			temdec=temdec+48;
			strcpy(temp,(char*)&temdec);
			tmp=i%10 +48;
			strcat(temp,(char*)&tmp);
		}
		else
		{
			int tmp=i+48;
			strcpy(temp,(char*)&tmp);
		}
		strcpy(resfile,tempfile);
		strcat(resfile,temp);
		strcat(resfile,".txt");

		/*****************************
			open file for output best agent index vs iteration
		*****************************************/
		if ((fp=fopen(resfile,"w"))==NULL)
		{
			printf("Cant write file");
			exit(1);
		}

		finish=0;

		do
		{
			iter++;
	printf("PSO Iterations: %d\n",
	iter);

			if (iter >32760) iter=0;   /* so it doesnt crash the data type */

			//update inertia weight
			weight_up = (weight-0.4) * (MAXITER - iter) /MAXITER +0.4;    //time variant weight, linear from weight to 0.4

			//weight_up=weight;		//constant inertia weight

			for (a=0;a<NUMBER_OF_AGENTS;a++)
			{

// Running SIMSENS from PSO


	sink_theta_ = xx[0][a]/360.*2*PI;
	sink_theta2_= xx[1][a]/360.*2*PI;
	sink_theta3_= xx[2][a]/360.*2*PI;

	sink_R	= topol->radius_;  	   // xx[1][a];
	sink_x1 = sink_R*cos(sink_theta_); // Relocation X of the sink position
	sink_y1 = sink_R*sin(sink_theta_); // Relocation Y of the sink position
	sink_x2 = sink_R*cos(sink_theta2_);// Relocation X of the sink position
	sink_y2 = sink_R*sin(sink_theta2_);// Relocation Y of the sink position
        sink_x3 = sink_R*cos(sink_theta3_);// Relocation X of the sink position
        sink_y3 = sink_R*sin(sink_theta3_);// Relocation Y of the sink position


	printf("\n\n\n----------------------\n");
	printf("PSO selected theta Values: %f %f Particle:%i\n",
	sink_theta_,sink_theta2_,a);

	printf("PSO selected Value ! Point 1: %f %f, Point 2:%f %f\n",
	sink_x1,sink_y1,sink_x2,sink_y2);

	printf("PSO current Particle Best: %f\n",
	pbest[gbest]);

// Moving through Straight Line p1 to p2

	m=(sink_y2-sink_y1)/(sink_x2-sink_x1);

//	Move Sink from Optimum position to Centre in a Straight Line
	printf("Stright Line Movement Started, moving from p1 to p2 !\n");

	TOT_distance=0;dtimes=0;

	if (sink_x1 > sink_x2)  // Sink Point 1 should be less than Point 2
	{sink_tempx1=sink_x2;sink_tempx2=sink_x1;}
 	else
	{sink_tempx1=sink_x1;sink_tempx2=sink_x2;}
		
	for(d=sink_tempx1;d<=sink_tempx2;d+=0.01)
	{
	topol->xreloc_sink_=d;
        topol->yreloc_sink_=((d-sink_x1)/m) + sink_y1;

	printf("Now X,Y: %f,%f\n",topol->xreloc_sink_,topol->yreloc_sink_);
	topol->createtopology(sim->simtype());
	//	topol->routing();
	//	sim->execute();
	//	if (Routing_Penalty==0)	break;
	TOT_distance+=uom_distance;

	dtimes++;
	}

// Moving through Straight Line p2 to p3

	m=(sink_y3-sink_y2)/(sink_x3-sink_x2);

//	Move Sink from Optimum position to Centre in a Straight Line
	printf("Stright Line Movement Started, moving from p2 to p3 !\n");


	if (sink_x2 > sink_x3)  // Sink Point 1 should be less than Point 2
	{sink_tempx2=sink_x3;sink_tempx3=sink_x2;}
	else
	{sink_tempx2=sink_x2;sink_tempx3=sink_x3;}
		
	for(d=sink_tempx2;d<=sink_tempx3;d+=0.01)
	{
	topol->xreloc_sink_=d;
        topol->yreloc_sink_=((d-sink_x2)/m) + sink_y2;

	printf("Now X,Y: %f,%f\n",topol->xreloc_sink_,topol->yreloc_sink_);
	topol->createtopology(sim->simtype());
	//	topol->routing();

	//	sim->execute();
	//	if (Routing_Penalty==0)	break;
	TOT_distance+=uom_distance;

	dtimes++;
	}
	minval = (float) TOT_distance/dtimes;

	printf("Average Distance: %f Min Val: %f\n",uom_distance,minval);

				if (firsttime==1) {
				pbest[a]=minval;
					pbestx1[a]=sink_x1;
					pbesty1[a]=sink_y1;
					pbestx2[a]=sink_x2;
					pbesty2[a]=sink_y2;
					pbestx3[a]=sink_x3;
					pbesty3[a]=sink_y3;}
					
	printf("Min Value : %f Particle Best: %f\n",minval,pbest[a]);
	if (minval<pbest[a]) printf("Min Value is less than Particle Best\n");

				if (minval < pbest[a])
				{
					pbest[a]=minval;
						pbestx1[a]=sink_x1;
						pbesty1[a]=sink_y1;
						pbestx2[a]=sink_x2;
						pbesty2[a]=sink_y2;
						pbestx3[a]=sink_x3;
						pbesty3[a]=sink_y3;


	printf("PSO Selecting Particle Best old: %f new: %f\n",
	pbest[gbest],minval);
					for (b=0;b<DIMENSION;b++) pbestx[b][a]=xx[b][a];
					if (pbest[a] < pbest[gbest])
						{
						gbest=a;

						}
				}

				/* asynchronous version */
				for (b=0;b<DIMENSION;b++)
				{
					dRandom=(rand()%step)/step;dRandom2=(rand()%step)/step;
					vx[b][a] = weight_up*vx[b][a] + 2*dRandom*(pbestx[b][a]-xx[b][a]) +
					2*dRandom2*(pbestx[b][gbest]-xx[b][a]);
					if (vx[b][a]>MAXV)
						vx[b][a]=MAXV;
					else if (vx[b][a]<-MAXV)
						vx[b][a]=-MAXV;
				}

				/*********************************
				Tx allows simultaneous updates
				*********************************/
				for (b=0; b<DIMENSION;b++)
				{
					tx[b][a]=xx[b][a]+vx[b][a];
				}
			}     	/* ******* END OF a LOOP ************************* */

			/* *******************************************************
				Update positions
			******************************************************** */
			for (a=0;a<NUMBER_OF_AGENTS;a++)
			{
				/* *******************************************************
					Define new coordinates
				******************************************************** */
				for (b=0;b<DIMENSION;b++)
				{
					xx[b][a] =tx[b][a];
				}

			}   /* end a loop  */

			/* *******************************************************
				In case iterations become greater than 32767
			******************************************************** */

			if (firsttime!=1)
			{
				if (iter==32766) iter=0;
			}
			/* ******************************************************
				Terminate on criterion
			********************************************************* */
			//output best index vs iteration

				fprintf(fp,"%f\n",pbest[gbest]);
				fprintf(fp," %f,%f to %f,%f then to %f,%f\n",
				pbestx1[gbest],pbesty1[gbest],pbestx2[gbest],
				pbesty2[gbest],pbestx3[gbest],pbesty3[gbest]);

				printf("Value written to file ! Point 1: %f,%f to Point 2:%f,%f\n",
				pbestx1[gbest],pbesty1[gbest],pbestx2[gbest],
				pbesty2[gbest],pbestx3[gbest],pbesty3[gbest]);


			if ((pbest[gbest] <= E_CUTOFF) || (iter >= MAXITER))
			{
				fclose(fp);
				printf("%d run finished!\n",i);
				finish=1;
			}
			firsttime=0;

		}     /* **************** End of do-loop *************** */
		while (! finish);
	}
	time(&tt);
	printf("end time: %s\n",ctime(&tt));
	return 0;

}
