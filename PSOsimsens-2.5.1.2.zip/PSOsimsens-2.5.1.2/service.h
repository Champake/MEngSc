/*
**  File:        service.h
**  Program:     Sensor 
**  Purpose:     service routines    
**  Author:      Michele Garetto
**  Last Update: November 11 2002
*/

#ifndef service_h
#define service_h

#define MAXROUTES 10
#define BUFFERSIZE 400
#define NUMSTATE 6
#define MAXCOMPL 400

#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include "sensor.h"

int get_int(); 
unsigned long get_long();
double get_double();
void get_string(char *s);
void error(char*s);


/* Random number generator */
class RNG
{

public:
	static double uniform() { return(gsl_rng_uniform_pos(rng_)); }
	static unsigned int geometric(double p) { return(gsl_ran_geometric(rng_,p)); }
	static void inputseed();
	static gsl_rng* rng() { return (rng_); }	
	
private:
	static gsl_rng* rng_;
};

#endif
