/*
**  File:        simulation.cc
**  Program:     Sensor 
**  Purpose:     class simulation      
**  Author:      Michele Garetto / Dario Panno
**  Last Update: January 21 2003
**  Edited:	 Champ Mendis
**  Last Edited: 23 August 2005
*/

#include <assert.h>
#include "simulation.h"
#include "service.h"

	
/*
**  Function : inputparamters()
**  Purpose:   Input parameters  
**              
*/
extern double uom_throughput,uom_Energy,Ftop; 
void Simulation::inputparameters()
{
	printf("Name of simulation: ");
  	get_string(name_);
  	printf("%s\n",name_);
	
	printf("Simulation type (1: single message - 2: multiple messages): ");
  	simtype_ = get_int();
	printf("%d\n",simtype_);
	if (simtype_ < 1 || simtype_ > 2) error("simulation type not valid");
	
	switch (simtype_) 
	{
		case 1: 
			printf("Radius of the source (meters): ");
			t_->r_source_ = get_double();
		   	printf("%f\n",t_->r_source_);
	           	if (t_->r_source_ <= 0.) error("Radius must be greater than zero !");
	  
	  	   	printf("Angle of the source (degree): ");
			t_->a_source_ = get_double();
	           	printf("%f\n",t_->a_source_);
		        if (t_->a_source_ < 0.) error("Angle must be greater than or equal to zero");
		        if (t_->a_source_ > 360.) error("Angle must be smaller or equal to 360");
		        t_->a_source_ = t_->a_source_/360.*2*PI;
			
			printf("Number of simulation runs: ");
  			nsimrun_ = get_long();
  			printf("%ld\n",nsimrun_);
  			if ((nsimrun_ < 1) || (nsimrun_ > MAXNSIMRUN)) error("Number of simulation runs not valid");
			
			nmsgstop_ = 1;
			nmsgmax_ = 1;
			nmsgreset_ = 2;
			t_->lambda_ = 0.;	
			t_->nsources_ = 0;
		   
			break;

		case 2: 
			nsimrun_ = 1;
		
			printf("Number of sources: ");
			t_->nsources_ = get_long();
			printf("%ld\n",t_->nsources_);
			if (t_->nsources_ < 1) error("Number of sources not valid (>=1)");
			
			printf("Transient duration (messages arrived at the sink): ");
  			nmsgreset_ = get_long();
			printf("%ld\n",nmsgreset_);
  			if ((nmsgreset_ < 0) || (nmsgreset_ > MAXMSG)) error("Number of msg not valid");   
			
			printf("Simulation duration (messages arrived at the sink): ");
  			nmsgstop_ = get_long();
			printf("%ld\n",nmsgstop_);
  			if ((nmsgstop_ < 0) || (nmsgstop_ > MAXMSG)) error("Number of msg not valid");
			
			printf("Maximum number of messages in the network: ");
  			nmsgmax_ = get_long();
			printf("%ld\n",nmsgmax_);
  			if ((nmsgmax_ < 0) || (nmsgmax_ > MAXMSG)) error("Number of msg not valid");
			
			printf("Generation rate of messages at each source: ");
			t_->lambda_ = get_double();
		   	printf("%f\n",t_->lambda_);
			if (t_->lambda_ < 0. || t_->lambda_ > 1) error("must be 0 <= lambda <=1 !");
			
			// t_->lambda_ = 0.9/t_->nsources_ * (t_->pIS_ + t_->pSI_)/t_->pSI_;
			
			break;
	}  	
}

/*
**  Function : execute()
**  Purpose:   executes the simulation  
**              
*/
void Simulation::execute()
{
  	unsigned long sim;
	int finished;
	FILE* fp = 0;
  
  	if(simtype_ == 2) fp = fopen("msgnet","w");
  	t_->resetstat();
	printf("\n\n");
	for(sim = 1; sim <= nsimrun_; sim++)
  	{
		t_->init(simtype_);
				
		finished = 0;
		printf("------------ Simulation run %ld --------------\n",sim);
		resetstep_ = 0L;
		
		for(step_ = 1; !finished && step_ < MAXSTEPS; step_++) {
	
			if((step_ % 100) == 0) printf("*** step: %ld - arrived = %ld\n",step_,t_->nmsgarr_); 
		
			t_->step(step_);
							
			/* check end of transient duration */
			if(t_->nmsgarr_ == nmsgreset_) { 
				t_->resetstat(); 
				nmsgreset_ = 0; 
				resetstep_ = step_;
			}
		
			/* check network instability */
			if(t_->nmsgnet_ > nmsgmax_) printf("Maximum number of messages in the network reached: %ld \n",t_->nmsgnet_); //cmendis
			if(t_->nmsgnet_ > nmsgmax_) error("Maximum number of messages in the network reached");
			if(simtype_ == 2 && (step_ % 10 == 0)) fprintf(fp,"%ld %ld %ld \n",step_,t_->nmsgarr_,t_->nmsgnet_);
					
			/* check messages arrived at the sink */
			if (t_->sink_->msgRX() >= nmsgstop_) finished = 1;
		}
		
		if(step_ == MAXSTEPS) error("Maximum number of steps reached");
		step_--; /* undo the last increment */
		// printf("*** Simulation finished at the end of step %ld\n",step_);
	}
	
	if(simtype_ == 2) fclose(fp);
	if(simtype_ == 1) printresults_single();
	if(simtype_ == 2) printresults_multi();  
}

/*
**  Function : printresults_single()
**  Purpose:   print out results for single message simulation   
**              
*/
void Simulation::printresults_single()
{
	FILE* fp;
	unsigned long i,max,min;
		
	fp = fopen(name_,"a");
	fprintf(fp,"### RESULTS FOR SIMULATION '%s' ###\n",name_);
	fprintf(fp,"### Average tx/rx energy per message = %8.4f \n",t_->source_->msgenergy_*1.0/nsimrun_);
	fprintf(fp,"### Average completion time = %8.4f \n",t_->source_->sumcompl_*1.0/nsimrun_);
	fprintf(fp,"### Average hop count = %8.4f \n",t_->source_->sumhops_ * 1.0/nsimrun_);
	
	fprintf(fp,"\n\n### Completion time distribution for the source:\n");
	max = 0; 
	for(i=1; i<=MAXCOMPL; i++) if(t_->source_->complf_[i] > 0) max = i;
	for(min=1; min<=MAXCOMPL && t_->source_->complf_[min] == 0; min++);
	for(i=min; i<=max; i++) fprintf(fp,"%4ld   %1.12f   %ld\n", 
		i, ((float)t_->source_->complf_[i])/nsimrun_, t_->source_->complf_[i]);
		 
	fprintf(fp,"\n\n### Hop count distribution for the source:\n");
	max = 0;
	for(i=1; i<=t_->nsens_; i++) if(t_->source_->hopf_[i] > 0) max = i;
	for(min=1; min<=t_->nsens_ && t_->source_->hopf_[min] == 0; min++);	
	for(i=min; i<=max; i++) fprintf(fp,"%4ld   %1.12f   %ld\n", 
		i, ((float)t_->source_->hopf_[i])/nsimrun_, t_->source_->hopf_[i]);
}
	
/*
**  Function : printresults_multi()
**  Purpose:   print out results for multiple message simulation   
**              
*/
void Simulation::printresults_multi()
{
	FILE *fp, *fd,*topo;
	Sensor *cur;
	Route *r;
	
	double totdelay,tothops,toterate,tottxrx;
	unsigned long totdel,totgen,i,min,max;
	double throughput,totlambdae,totavebuf;
			
	fp = fopen(name_,"a");
	fd = fopen("compl.sim","a");
	if (Ftop==0) 
	topo = fopen("topo.run","w");
	fprintf(fp,"### RESULTS FOR SIMULATION '%s' ###\n",name_);
	
	fprintf(fp,"\n\n### Statistics for each sensor:\n");
	fprintf(fp,"### ID      dist             X              Y          "
	"LAMBDA_E       LAMBDA_I       LAMBDA_O       AVEBUF       "
	"AVECOMPL       AVEHOPS       AVETXRX      AVEERATE          "
	"RX        TX      LOST       GEN      DEL      "
	"active         activeteor        SLEEP          ACTIVE_IDLE     ACTIVE_TX       "
	"ACTIVE_RX         DROWSY_IDLE      DROWSY_TX      alfa          alfa1         beta          "
	"beta1         AVEBUFT        AVEBETA         AVEALFA       "
	"aveErxtx       aveEtran        aveEtot\n");
	
	/* initializations */
	throughput = 0.;
	totdelay = 0.;
	tothops = 0.;
	tottxrx = 0.;
	toterate = 0.;
	totdel = 0;
	totgen = 0;
	totlambdae = 0.;
	totavebuf = 0.;
	gsl_matrix_set_zero(t_->L_);
	
	/* effective steps */
	step_ -= resetstep_;
	
	for (cur = t_->sink_; cur != 0; cur = cur->next_)
	{
		cur->computestat(step_);
		
		for(r = cur->firstr_; r != NULL; r = r->next_) gsl_matrix_set(t_->L_,cur->id(),r->N_->id(),r->ntx_*1.0/step_);
				
		throughput += cur->lambda() * cur->pI();
		totdelay += cur->sumcompl_;
		tothops += cur->sumhops_;
		tottxrx += cur->msgenergy_;
		toterate += cur->aveerate + cur->aveetxrx + cur->aveetran;
		totdel += cur->msgDEL();
		totgen += cur->msgGEN();
		totlambdae += cur->lambda_e;
		totavebuf += cur->avebuf;
	
		fprintf(fp,"%6ld  %e  %13e  %13e   "
		"%e   %e   %e  %e  "
		"%e  %e  %e  %e  "
		"%8ld  %8ld  %8ld  %8ld %8ld   "
		"%e     %e   %e      %e    %e    "
		"%e      %e    %e  "
		"%e  %e  %e  %e   %e   %e    %e    "
		"%e   %e   %e\n",
		cur->id(), cur->dist(), cur->x(), cur->y(),
		cur->lambda_e, cur->lambda_i, cur->lambda_o, cur->avebuf,
		cur->avecompl, cur->avehops, cur->avetxrx, cur->aveerate,
		cur->msgRX(), cur->msgTX(), cur->msgLOST(), cur->msgGEN(), cur->msgDEL(),
		cur->pi_active, cur->pI(), cur->pi_state_[SLEEP], cur->pi_state_[ACTIVE_IDLE], cur->pi_state_[ACTIVE_TX],
		cur->pi_state_[ACTIVE_RX], cur->pi_state_[DROWSY_IDLE], cur->pi_state_[DROWSY_TX],
		cur->alfa,cur->alfa1,cur->beta,cur->beta1,cur->avebuft_,cur->avebeta,cur->avealfa,
		cur->aveetxrx, cur->aveetran, cur->aveerate + cur->aveetxrx + cur->aveetran);

//	if (Ftop==0) 
//	fprintf(topo,"%13e  %13e\n",cur->x(), cur->y());
	}
	fprintf(fp,"\n\n### Global statistics:\n");
	fprintf(fp,"### Effective steps = %ld\n",step_);
	fprintf(fp,"### Total messages generated = %ld\n",totgen);
	fprintf(fp,"### Total messages delivered = %ld\n",totdel);
	fprintf(fp,"### Desired aggregated throughput = %f\n",throughput);

	uom_throughput=totdel*1.0/step_; 	//Passing to PSO
	fprintf(fp,"### Aggregated throughput obtained = %f\n",uom_throughput);

	fprintf(fp,"### total external rate = %f\n",totlambdae);
	fprintf(fp,"### Average completion time = %e\n",totdelay *1.0/ totdel);
	fprintf(fp,"### Average completion time (Little) = %ef\n",totavebuf/totlambdae);
	fprintf(fp,"### Average number of hops = %8.4f\n",tothops *1.0/ totdel);
	fprintf(fp,"### Average tx/rx energy per message = %8.4f\n",tottxrx*1.0/ totdel);
	fprintf(fp,"### Average dissipation rate per sensor = %e\n",toterate*1.0/t_->nsens_);
	uom_Energy = tottxrx;

	/* completion times distributions */
	for (cur = t_->sink_->next_; cur != 0; cur = cur->next_) if(cur->msgDEL_ > 0)
	{
		fprintf(fd,"\n\n### Completion time distribution of sensor %ld:\n",cur->id());
		max = 0;
		for(i=1; i<=MAXCOMPL; i++) { if(cur->complf_[i] > 0.) max = i; }
		for(min=1; (min<=MAXCOMPL) && (cur->complf_[min] == 0); min++); 
		for(i=min; i<=max; i++) {
			fprintf(fd,"%6ld   %1.12f\n", i, cur->complf_[i]*1.0/cur->msgDEL_);
		}	
	}	
					

	// Topology consistent Strategy
 // Create Topology file if not available	
	fclose(fp);
	fclose(fd);
	if (Ftop==0){fclose(topo);Ftop=1;}
}	
	
