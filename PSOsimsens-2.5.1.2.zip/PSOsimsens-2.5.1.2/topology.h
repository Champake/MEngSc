/*
**  File:        topology.h
**  Program:     Sensor 
**  Purpose:     class topology      
**  Author:      Michele Garetto / Dario Panno
**  Last Update: January 21 2003
*/


#ifndef topology_h
#define topology_h

#include "sensor.h"

#define MAXNSENS 100000
#define MAXPOWERLEVELS 100
#define MAXMSG 10000000
#define MAXNSIMRUN 100000000
#define MAXSTEPS 1000000000
#define COMPLPREC 1e-6
#define MAXCAR 255
// #define PI 3.141592654
#define PI M_PI


class Topology {
friend class Simulation;
public:

	Topology() {}
	
	void createtopology(int symtype);
	void routing();
	void inputparameters();
	void init(int symtype);
	void resetstat();
	void step(unsigned long step);
	void buildmatrix(gsl_matrix *m);
	void buildinterf();	
	
	inline double getenergy(Sensor *s1, Sensor *s2) { return(gsl_matrix_get(E_,s1->id(),s2->id())); }
	inline double getenergy2(unsigned long id1, unsigned long id2) { return(gsl_matrix_get(E_,id1,id2)); }
	inline double getdist(Sensor *s1, Sensor *s2) { return(gsl_matrix_get(D_,s1->id(),s2->id())); }
	inline double getdist2(unsigned long id1, unsigned long id2) { return(gsl_matrix_get(D_,id1,id2)); }
	
	inline unsigned long& nmsgnet() { return(nmsgnet_); }
	inline unsigned long& nmsgarr() { return(nmsgarr_); }
	
	Sensor * sink_;                  /* pointer to the sink, the first element of the list of all sensors */ 
	Sensor * source_;      		 /* pointer to the single source in case of single message */
	Sensor ** sensors_;		 /* pointers to all sensors indexed by ID */
	unsigned long * indexes_;	 /* vector of indexes to make the permutation */ 

	/* topology parameters */
	unsigned long nsens_;		 /* number of sensors */ 
	double radius_; 		 /* radius of area containing the sensors (meters) */
	double theta_min_;		 /* min angle of the arc describing the area */
	double theta_max_;		 /* min angle of the arc describing the area */
	double r_sink_; 		 /* radius coordinate of the sink position */
	double a_sink_; 		 /* angle coordinate of the sink position */
	double xreloc_sink_; 		 /* Relocation X of the sink position */
	double yreloc_sink_; 		 /* Relocation Y of the sink position */
	double r_source_;		 /* radius coordinate of the source position */
	double a_source_;		 /* angle coordinate of the source position */
	int nroutes_;    		 /* number of alternate routes maintained by each sensor */

	/* energy parameters */
	double maxdist_;         /* maximum distance reachable by the sensor transmitter */
	int powlevels_;		 /* number of power levels (0 = continuous) */
	double* maxdistlevel_;	 /* maximum distance reachable using power level "i" */
	double* powlevel_;	 /* Energy consumed to transmit a message using power level "i" */  
	double ERXelec_;	 /* energy consumed to receive a message by receive electronics */	 
	double ETXelec_;	 /* energy consumed to transmit a message by transmit electronics */
	double ETXrad1_;	 /* energy consumed by transmit amplifier to transmit a message one meter away */
	double Eidle_;  	 /* energy consumed in IDLE state during a time step */
	double Esleep_; 	 /* energy consumed in SLEEP state during a time step */
	double Eis_;		 /* energy consumed by a transition IDLE -> SLEEP */
	double Esi_;		 /* energy consumed by a transition SLEEP -> IDLE */
	double alpha_;  	 /* propagation attenuation exponent */
	double pSI_;    	 /* transition probability SLEEP -> IDLE */
	double pIS_;    	 /* transition probability IDLE -> SLEEP */
	
	int contentionmodel_;	 /* channel contention model */
	
protected:

	void insertsensor(Sensor *);
	int flooding(Sensor *);
	void recoverisolated();
	double energy(Sensor *, Sensor *); 
	
	unsigned long nmsgnet_;		 /* number of messages currently in the network */
	unsigned long nsources_;	 /* number of sources */
	unsigned long nisolated_;	 /* number of isolated nodes */
	double lambda_;		 	 /* generation rate of each source */
	unsigned long nmsgarr_;		 /* number of messages arrived at the sink */
	
	gsl_matrix * E_;	 /* energy matrix */
	gsl_matrix * D_;	 /* distance matrix */
	gsl_matrix * L_;	 /* internal lambdas */
	gsl_matrix * Lest_;	 /* estimated internal lambdas */
};	

#endif
