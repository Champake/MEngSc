/*
**  File:        topology.cc
**  Program:     Sensor 
**  Purpose:     class topology      
**  Author:      Michele Garetto / Dario Panno
**  Last Update: January 21 2003
**  Edited:	 16 August 2005
**  Notes:	 Sensor Creation blocked
*/

#include <assert.h>
#include <math.h>

#include "topology.h"
#include "service.h"

double y_cutoff_=0.1;

/*
**  Function : init(int simtype)
**  Purpose: initialization of all sensors before starting a new simulation run  
*/
extern int topology_done;
extern int Routing_Penalty;
float ratio;
extern double uom_topology[60][2];
extern double uom_distance; // Distance Variable - cm

void Topology::init(int simtype)
{
	Sensor *cur;
	Message* m;
	
	for (cur = sink_; cur != 0; cur = cur->next_) cur->init();
	nmsgnet_ = 0L;
	nmsgarr_ = 0L;
		
	if (simtype == 1){ 
		
		/* the source is initially ACTIVE_IDLE and generates a message */
		printf("Generate Message in the Source: %ld\n",source_->id());
		source_->state() = ACTIVE_IDLE; 
		source_->tauI() = RNG::geometric(pIS_); 
		m = Message::alloc(source_); 
		m->stepstart() = 1;
		source_->q_->enque(m);
		source_->msgGEN_++;
		nmsgnet_++;
		
		/* reset at sink */
		sink_->msgRX_ = 0L;
	}		
}

/*
**  Function : resetstat()
**  Purpose: reset statistics at the end of the transient period  
*/
void Topology::resetstat()
{
	Sensor *cur;	
	for (cur = sink_; cur != 0; cur = cur->next_) cur->resetstat();
}

/*
**  Function : step()
**  Purpose: executes a new step    
*/
void Topology::step(unsigned long step)
{	
	Sensor *cur; 
	
	/* evoluzione all'inizio dello step*/
	for (cur = sink_; cur != 0; cur = cur->next_) cur->evolve(step);
	
	/* random permutation of indexes */
	gsl_ran_shuffle (RNG::rng(), indexes_, nsens_+1, sizeof (unsigned long));
	/* execution of sensors according to permutation */
	for(unsigned long n = 0; n <= nsens_; n++) sensors_[indexes_[n]]->operate(step);
		
	/* update statistics */
	for (cur = sink_; cur != 0; cur = cur->next_) cur->updatestat(step);
}	
	
/*
**  Function : insertsensor(Sensor* s)
**  Purpose: insert a new Sensor into the list of ordered sensors (according to distance from the sink) 
*/
void Topology::insertsensor(Sensor* s)
{
	Sensor *cur,*prec;
	s->dist() = s->distance(sink_);
	for (prec = sink_, cur = sink_->next_; (cur != 0) && (cur->dist() < s->dist()); prec = cur, cur = cur->next_);
	prec->next_ = s;
	if(cur) s->next_ = cur;
}
	
/*
**  Function : inputparamters()
**  Purpose:   Input parameters  
**              
*/
void Topology::inputparameters()
{

	printf("Number of sensors: ");								 	 
	nsens_ = get_long();
	printf("%ld\n",nsens_);
	if ((nsens_ < 1) || (nsens_ > MAXNSENS)) error("Number of sensors not valid");
	 
	printf("Area radius (meters): ");
	radius_ = get_double();
	printf("%f\n",radius_);
	if (radius_ <= 0.) error("Radius must be greater than zero !");
	  
	printf("Area min angle (degree): ");
	theta_min_ = get_double();
	printf("%f\n",theta_min_);
	if (theta_min_ < 0.) error("Min angle must be greater than or equal to zero");
	if (theta_min_ >= 360.) error("Min angle must be smaller than 360");
	theta_min_ = theta_min_/360.*2*PI;
	  
	printf("Area max angle (degree): ");
	theta_max_ = get_double();
	printf("%f\n",theta_max_);
	if (theta_max_ <= theta_min_) error("Max angle must be greater than min angle !");
	if (theta_max_ > 360.) error("Min angle must be smaller than or equal to 360");
	theta_max_ = theta_max_/360.*2*PI;
	  
	printf("Radius of the sink (meters): ");
	r_sink_ = get_double();
	printf("%f\n",r_sink_);
	if (r_sink_ < 0.) error("Radius must be greater than zero !");
	  
	printf("Angle of the sink (degree): ");
	a_sink_ = get_double();
	printf("%f\n",a_sink_);
	if (a_sink_ < 0.) error("Angle must be greater than or equal to zero");
	if (a_sink_ > 360.) error("Angle must be smaller or equal to 360");
	a_sink_ = a_sink_/360.*2*PI;
	  
	printf("X Relocation of the sink (meters): ");
	xreloc_sink_ = get_double();
	printf("%f\n",xreloc_sink_);
	if (xreloc_sink_ > radius_) error("Relocation must be smaller than or equal to radius");

	printf("Y Relocation of the sink (meters): ");
	yreloc_sink_ = get_double();
	printf("%f\n",yreloc_sink_);
	if (yreloc_sink_ > radius_) error("Relocation must be smaller than or equal to radius");

	printf("Number of alternate routes: ");
	nroutes_ = get_int();
	printf("%d\n",nroutes_);
	if ((nroutes_ < 1) || (nroutes_ > MAXROUTES)) error("Number of routes not valid");

	printf("Maximum distance reachable by the sensor transmitter: ");
	maxdist_ = get_double();		     		     		     	     
	printf("%f\n",maxdist_);							     	     
	if (maxdist_ <= 0.) error("The maximum distance must be greater than zero !");	
	
	printf("Power levels: (0: continuous, <n>: discrete) : ");
	powlevels_ = get_int();
	printf("%d\n",powlevels_);
	if ((powlevels_ < 0) || (powlevels_ > MAXPOWERLEVELS)) error("Power levels not valid");
	
	if(powlevels_ == 0) {
	
		printf("Energy consumed by transmit amplifier to reach one meter (per message): ");
		ETXrad1_ = get_double();	     							     	     
		printf("%f\n",ETXrad1_);							     	     
		if (ETXrad1_ < 0.) error("Energy must be greater than or equal to zero !");
	  										     	     
		printf("Propagation attenuation exponent: "); 
		alpha_ = get_double();				     	     							     	     
		printf("%f\n",alpha_);							     	     
		if (alpha_ < 1.) error("Exponent must be greater than or equal to one !");	
		
	} else {
		int i;
		double tmp,max;
		powlevel_ = new double[powlevels_+1];
		maxdistlevel_ = new double[powlevels_+1];
		max = 0.0;
		for(i = 1; i<=powlevels_; i++) {
		
			printf("Maximum distance reachable using power level %d: ",i);
			tmp = get_double();		     		     		     	     
			printf("%f\n",tmp);							     	     
			if ((tmp <= max) || (tmp > maxdist_)) error("Distance value not valid !");	
			maxdistlevel_[i] = tmp;
			max = tmp;
			
			printf("Energy consumed to transmit a message using power level %d: ",i);
			tmp = get_double();	     							     	     
			printf("%f\n",tmp);							     	     
			if (tmp < 0.) error("Energy must be greater than or equal to zero !");		
			powlevel_[i] = tmp;
		}
	}		
			

	printf("Energy consumed by receive electronics (per message): ");
	ERXelec_ = get_double();		     		     		     	     
	printf("%f\n",ERXelec_);							     	     
	if (ERXelec_ < 0.) error("Energy must be greater than or equal to zero !");	     	     
	  										     	     
	printf("Energy consumed by transmit electronics (per message): ");
	ETXelec_ = get_double();		     	     				     	     
	printf("%f\n",ETXelec_);							     	     
	if (ETXelec_ < 0.) error("Energy must be greater than or equal to zero !");	     	     
	  										     	     
	printf("Energy consumed in IDLE state (per time step): ");
	Eidle_ = get_double();			     	     							     	     
	printf("%f\n",Eidle_);							     	     
	if (Eidle_ < 0.) error("Energy must be greater than or equal to zero !");	     	     
	  										     	     
	printf("Energy consumed in SLEEP state (per time step): ");
	Esleep_ = get_double();			     	     							     	     
	printf("%f\n",Esleep_);							     	     
	if (Esleep_ < 0.) error("Energy must be greater than or equal to zero !");	   
	
	printf("Energy consumed by a transition SLEEP -> IDLE: ");
	Esi_ = get_double();			     	     							     	     
	printf("%f\n",Esi_);							     	     
	if (Esi_ < 0.) error("Energy must be greater than or equal to zero !");	  
	
	printf("Energy consumed by a transition IDLE -> SLEEP: ");
	Eis_ = get_double();			     	     							     	     
	printf("%f\n",Eis_);							     	     
	if (Eis_ < 0.) error("Energy must be greater than or equal to zero !");	     	     
	  										     	     
	printf("Transition probability SLEEP -> IDLE: ");
	pSI_ = get_double();				     	     							     	     
	printf("%f\n",pSI_);								     	     
	if (pSI_ < 0.) error("Probability must be greater than or equal to zero !");	     	     
	if (pSI_ > 1.) error("Probability must be smaller than or equal to one !"); 	     	     
	 										     	     
	printf("Transition probability IDLE -> SLEEP: ");	
	pIS_ = get_double();			     	     						     	     
	printf("%f\n",pIS_);								     	    
	if (pIS_ < 0.) error("Probability must be greater than or equal to zero !");	     	     
	if (pIS_ > 1.) error("Probability must be smaller than or equal to one !"); 
	
	printf(" Channel contention model (0: none - 1: ideal RTS/CTS): ");
  	contentionmodel_ = get_int();
	printf("%d\n",contentionmodel_);
	if (contentionmodel_ < 0 || contentionmodel_ > 1) error("value not valid");	     
}	

/*
**  Function : createtopology(int simtype)
**  Purpose: create the sensor network topology, placing the sensors randomly in the defined area 
**           The sensor density is uniform over the area
*/
void Topology::createtopology(int simtype){

	unsigned long n,i,j,offset;
	double r,a,delta_theta,e,d;
	Sensor *s;
	unsigned long count = nsources_;
	double cutoff_;
	
	cutoff_=radius_-y_cutoff_;
	uom_distance = 0.0;	// Distance Variable initialization - cm
	printf("Topology generation...\n");
	
	/* alloc arrays indexes_ and sensors_ */	
	indexes_ = new unsigned long[nsens_+1]; assert(indexes_ != 0);	
	for (n = 0; n <= nsens_; n++) indexes_[n] = n;
	sensors_ = new Sensor* [nsens_+1]; assert(sensors_ != 0);


	/* creation of the sink */	
	sink_ = new Sink(this,xreloc_sink_,yreloc_sink_,1.,0.); /* the sink never sleeps */	
//	sink_ = new Sink(this,(r_sink_*cos(a_sink_))+xreloc_sink_,(r_sink_*sin(a_sink_))+yreloc_sink_,1.,0.); /* the sink never sleeps */	
//	sink_ = new Sink(this,r_sink_*cos(a_sink_),r_sink_*sin(a_sink_),1.,0.); /* the sink never sleeps */	
	sink_->id() = 0;
	sensors_[0] = sink_; 
	sink_->dist() = 0.;
	sink_->lambda() = 0.;
		
	delta_theta = theta_max_ - theta_min_;
		if (simtype == 1)
		{ 

			if (topology_done!=1)
			{
				uom_topology[1][1]= r_source_*cos(a_source_); // X Coordinate
				uom_topology[1][2]= r_source_*sin(a_source_); // Y Coordinate
			}	
			source_ =  new Sensor(this, uom_topology[1][1],uom_topology[1][2],pSI_,pIS_);

			source_->id() = 1;
			sensors_[1] = source_; 
			source_->lambda() = 0.;
			source_->nroutes() = nroutes_;
			insertsensor(source_);
			offset = 2;
		} else offset = 1;
	
		for(n = offset; n <= nsens_; n++)
		{
			r = radius_ * sqrt(RNG::uniform());
                	a = theta_min_ + RNG::uniform() * delta_theta;  
			if (topology_done!=1)
			{
				uom_topology[n][1]=r*cos(a); // X Coordinate
				uom_topology[n][2]=r*sin(a); // Y Coordinate
				if ((uom_topology[n][2]>cutoff_)||
				(uom_topology[n][2]<-cutoff_))
				{n--;continue;}
			}	
			s = new Sensor(this, uom_topology[n][1],uom_topology[n][2],pSI_,pIS_); 
			s->id() = n;
			sensors_[n] = s; 
			if(count > 0) {
				s->lambda() = lambda_;
				count--;
			} else s->lambda() = 0.;	
 			s->nroutes() = nroutes_;
			insertsensor(s);

		}			
	if (topology_done!=1) topology_done=1;
	
	printf("Done.\n");
	printf("Sensors in Sequence:\n");
	Routing_Penalty=nsens_;
	for (s = sink_; s != 0; s = s->next_) 
	{
	if(s->lambda() != 0) printf("ID = %ld X=%f Y=%f - dist = %f - lambda %f **SOURCE**\n",
	s->id(),s->x(),s->y(),s->dist(),s->lambda());
	else printf("ID = %ld X=%f Y=%f - dist = %f\n",s->id(),s->x(),s->y(),s->dist());

	uom_distance+=s->dist(); // Distance Aggregation - cm
	
	if (s->dist()>= maxdist_) Routing_Penalty--;}
	ratio= (float) Routing_Penalty/nsens_;
	printf("TEST Ratio of Tranmission = %f\n",ratio);	
	// if (Routing_Penalty==0)	return;

	/* Create a matrix of Distances and time */
	D_ = gsl_matrix_calloc(nsens_+1,nsens_+1);
	for(i = 0; i <= nsens_; i++) for(j = i+1; j <= nsens_; j++) {
		d = sensors_[i]->distance(sensors_[j]);
		gsl_matrix_set(D_,i,j,d);	
		gsl_matrix_set(D_,j,i,d);
	}	

	uom_distance=uom_distance/nsens_; // Average Distances - cm
		
	/* Create a matrix of energies and time */
	E_ = gsl_matrix_calloc(nsens_+1,nsens_+1);
	for(i = 0; i <= nsens_; i++) for(j = i+1; j <= nsens_; j++) {
		e = energy(sensors_[i],sensors_[j]);
		gsl_matrix_set(E_,i,j,e);	
		gsl_matrix_set(E_,j,i,e);
	}		
	
	/* Alloc matrix for internal lambdas */
	L_ = gsl_matrix_calloc(nsens_+1,nsens_+1);
	Lest_ = gsl_matrix_calloc(nsens_+1,nsens_+1);
}	

/*
**  Function : double energy(Sensor *s1, Sensor *s2)
**  Purpose: energy required to transmit a message from sensor s1 to sensor s2
**	     return -1 if out of range
*/
double Topology::energy(Sensor *s1, Sensor *s2)
{
	double ret = -1.;
	double dist = getdist(s1,s2);
	
	if(dist <= maxdist_) {
	
		if(powlevels_ == 0) {
			ret = ETXrad1_* pow(dist,alpha_);		
		} else {
			int i;
			for(i = 1; ret < 0. && i <= powlevels_; i++) if(dist < maxdistlevel_[i]) {
				ret = powlevel_[i];
			}
		}
	}	
	
	if (ret >= 0.) ret += ERXelec_ + ETXelec_;
	return(ret);
}			

/*
**  Function : int flooding(Sensor *s)
**  Purpose: flood the information of the best route of sensor 's' to all of the other sensors, increasing
**	     the total amount of energy according to the energy required by the new hop
**	     Finally, sets the flood flag of sensor 's' to zero
*/
int Topology::flooding(Sensor *s)
{
	Sensor *n;
	double oldE, newE;
	
	oldE = s->bestE();
	
	if(oldE < 0) return(0);
		
	for(n = sink_->next_; n != 0; n = n->next_) if(n != s) {
	
		/* discard sensors closer to the sink */
		 if(n->dist() <= s->dist()) continue;
		
		newE = getenergy(s,n);
		
		/* discard sensors out of range */
		if(newE < 0.) continue;
			
		newE += oldE;
		n->update(s,newE);
	}
	s->flood() = 0;
	return(1);
}		
		
/*
**  Function : routing()
**  Purpose: computes the routes of all sensors (operation performed only once at the beginning)
**           each sensor builds a list of up to "nroutes_" elements, ordered according to the minimum energy
**	     necessary to get to the sink over the best path.
*/
void Topology::routing(){

	Sensor *s;
	Route *cur;
	int i;
	int iter = 1;
	int flooded = 1;
	
	printf("\nComputation of routing ...\n"); fflush(stdout);
	
	/* virtual update to trigger the initial flooding from the sink */
	sink_->update(0,0.);
	
	while (flooded) {
		flooded = 0;
		for(s = sink_; s != 0 && !flooded; s = s->next_) {
			if(s->flood()) {
				flooded = flooding(s);
			}
		}	
		iter++;	
	}
	
	printf("Done (number of iterations: %d) !\n",iter);
	for(s = sink_->next_; s != 0; s = s->next_) s->printroutes();

	/* check isolated nodes */
	nisolated_ = 0;
	for(s = sink_->next_; s != 0; s = s->next_) if(s->bestE() < 0) {
		s->isolated() = 1;
		nisolated_++; 
	} else {
		s->isolated() = 0;
	}
			
	if(nisolated_) {
		printf("Warning ! %ld sensors without next hop. Try to recover ? (0/1) ",nisolated_);
		iter = get_int();
		printf("%d\n",iter);
		if(iter) recoverisolated();
		
		if(nisolated_) {
			printf("Warning ! %ld sensors without next hop. Continue anyway ? (0/1) ",nisolated_);
			iter = get_int();
			printf("%d\n",iter);
			if(!iter) exit(0); 
		}	
	}	
	
	/* set actual number of routes for each sensor */
	for(s = sink_->next_; s != 0; s = s->next_) {
		for(cur = s->firstr_, i=0; cur != NULL; cur = cur->next_, i++) 
		s->nroutes() = i;
	}		
}	

/*
**  Function : void recoverisolated()
**  Purpose: Try to recover isolated nodes 
*/
void Topology::recoverisolated()
{
	Sensor *n, *s;
	double oldE, newE;
	int improvement;
	
	do {
		improvement = 0;
		for(s = sink_->next_; s != 0; s = s->next_) if(s->bestE() >= 0.) {
			
			oldE = s->bestE();
	
			for(n = sink_->next_; n != 0; n = n->next_) if(n->isolated()) {
	
				newE = getenergy(s,n);
		
				/* discard sensors out of range */
				if(newE < 0.) continue;
			
				newE += oldE;
				n->update(s,newE);
				improvement = 1;
			}
		}	
		
		/* compute again isolated nodes */
		nisolated_ = 0; 
		for(s = sink_->next_; s != 0; s = s->next_) if(s->bestE() < 0) {
			s->isolated() = 1;
			nisolated_++; 
		} else {
			s->isolated() = 0;
		}	
		
		printf("Now isolated nodes = %ld\n",nisolated_);
				
			
	} while (improvement && nisolated_);
	
	for(s = sink_->next_; s != 0; s = s->next_) s->printroutes();
}	
	
		
	
	


