/*
**  File:        queue.cc
**  Program:     Sensor 
**  Purpose:     Class MessageQueue    
**  Author:      Michele Garetto
**  Last Update: January 10 2002
*/

#include "queue.h"
#include "service.h"

void MessageQueue::remove(Message* target)
{
	for (Message *ss= 0, *s= head_; s; ss = s, s = s->next_) {
		if (s == target) {
			if (!ss) deque();
			else {
				if (s == tail_) 
					tail_= ss;
				ss->next_= s->next_;
				--len_;
			}
			return;
		}
	}
	error("MessageQueue:: remove() couldn't find target");
}

void MessageQueue::remove(Message* s, Message *prev)
{
	if (s) {
		if (head_ == s)
			MessageQueue::deque(); /* decrements len_ internally */
		else {
			prev->next_ = s->next_;
			if (tail_ == s)
				tail_ = prev;
			--len_;
		}
	}
	return;
}

