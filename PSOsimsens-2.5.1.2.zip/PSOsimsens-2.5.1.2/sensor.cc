/*
**  File:        sensor.cc
**  Program:     Sensor 
**  Purpose:     Class Sensor       
**  Author:      Michele Garetto / Dario Panno
**  Last Update: January 21 2003
*/

#include <assert.h>
#include "sensor.h"
#include "service.h"
#include "topology.h"

Sensor::Sensor(Topology* t) : next_(0), x_(0.), y_(0.), dist_(-1.), pSI_(1.), pIS_(1.),   
	t_(t), state_(ACTIVE_IDLE), firstr_(0), lastr_(0), nr_(0), flood_(-1)
{ 
	alloc();
}

Sensor::Sensor(Topology* t, double x, double y) : next_(0), x_(x), y_(y), dist_(-1.), 
        pSI_(1.), pIS_(1.), t_(t), state_(ACTIVE_IDLE), firstr_(0), lastr_(0), nr_(0), 
	flood_(-1)
{
	alloc();
}

Sensor::Sensor(Topology* t, double x, double y, double pSI, double pIS) : next_(0), x_(x), 
        y_(y), dist_(-1.), pSI_(pSI), pIS_(pIS), t_(t), state_(ACTIVE_IDLE), firstr_(0), lastr_(0), 
	nr_(0), flood_(-1)
{
	alloc();
}

void Sensor::alloc()
{
	qlf_ = new unsigned long[BUFFERSIZE+1];
	assert(qlf_ != 0);
	sf_ = new unsigned long[NUMSTATE+1];
	assert(sf_ != 0);
	q_ = new MessageQueue; 
	complf_ = new unsigned long[MAXCOMPL+1];
	assert(complf_ != 0);
	hopf_ = new unsigned long[t_->nsens_+1];
	assert(hopf_ != 0);
}	
	
/*
**  Function : distance(Sensor& s) 
**  Purpose:   compute the physical distance between two sensors 
*/
double Sensor::distance(Sensor* s) {

	double tmp1 = s->x() - this->x();
	double tmp2 = s->y() - this->y();
	return(sqrt(tmp1*tmp1 + tmp2*tmp2));
	
}	

/*
**  Function : init()
**  Purpose:   Initialization, choosing the initial state randomly  
*/
void Sensor::init()
{
	Message* s;
	Route *cur;
	
	/* stationary probabilities */
	pS_ = pIS_/(pIS_+pSI_);
	pI_ = pSI_/(pIS_+pSI_);
	
	/* empty buffer */
	while((s = q_->deque())!=0) Message::free(s);
	
	if(RNG::uniform() < pS_)
	{
		state_ = SLEEP; 
		could_RX_ = 0;
		could_TX_ = 0;
		tauS_ = RNG::geometric(pSI_);
	} else {
		state_ = ACTIVE_IDLE;
		could_RX_ = 1;
		could_TX_ = 1;	
		if(pIS_>0) tauI_ = RNG::geometric(pIS_); else tauI_ = -1;
	}
	
	if(lambda_ > 0.) {
		nextarrival_ =  RNG::geometric(lambda_);
		// printf("Init Source %ld : nextarrival = %d\n",id_,nextarrival_);
	}	
	
	/* initialize routes usage */
	for(cur = firstr_; cur != NULL; cur = cur->next_) cur->ntx_ = 0; 
}	

/*
**  Function : computestat()
**  Purpose:   compute statistics for the device  
*/
void Sensor::computestat(unsigned long steps)
{
	unsigned long i,j;
	double sum;
	Route *cur;
	
	for(i=0; i<NUMSTATE; i++) {
		pi_state_[i] = sf_[i] * 1.0 / steps;
	}

	avebuf = 0.;
	for(i=0; i<=BUFFERSIZE; i++) {
		avebuf += i * qlf_[i]; 
	}
	avebuf /= steps;
		
	pi_active = 1.0 - pi_state_[SLEEP];
	aveerate = pi_state_[SLEEP] * t_->Esleep_ + pi_active * t_->Eidle_; 
	
	if(msgDEL() > 0) {
		avecompl = sumcompl_*1.0/msgDEL();
		avehops = sumhops_*1.0/msgDEL();  
		avetxrx = msgenergy_*1.0/msgDEL();  
	} else {
		avecompl = avehops = avetxrx = -1.;	
	}
	
	if(buftnum_ > 0) {
		avebuft_ = buftsum_*1.0/buftnum_;
	} else {
		avebuft_ = 0.0; 	
	}
	
	lambda_e = msgGEN() * 1.0 / steps;
	lambda_i = msgRX() * 1.0 / steps;
	lambda_o = msgTX() * 1.0 / steps;
	
	/* computation of aveetxrx */
	aveetxrx = 0.0;
	for(cur = firstr_; cur != NULL; cur = cur->next_) {
		j = cur->N_->id();
		aveetxrx  += cur->ntx_* 1.0/steps * t_->getenergy2(id_,j);
	}
	
	/* computation of aveetxrx */
	aveetran = aveetran/steps;	
	
	pisleep_ = pi_state_[SLEEP];
	piactiveR_ = pi_state_[ACTIVE_IDLE] + pi_state_[ACTIVE_RX] + pi_state_[ACTIVE_TX];
	piactiveN_ = pi_state_[DROWSY_IDLE] + pi_state_[DROWSY_TX];
	
	sum = pisleep_+piactiveR_+piactiveN_;
	if(fabs(sum-1.0) > 1e-9) error("Sensor: sum of probabilities is not one"); 
	
	if(sumalpha_>0) {
		alfa = alphaf_*1.0/sumalpha_;
		avealfa = (alphaf_ + alpha1f_)*1.0/(sumalpha_+sumalpha1_); 
	} else { alfa = 0.; avealfa = 0.; }
	if(sumalpha1_>0) alfa1 = alpha1f_*1.0/sumalpha1_; else alfa1 = 0.;
	
	if(sumbeta_>0) {
		beta = betaf_*1.0/sumbeta_; 
		avebeta = (betaf_ + beta1f_)*1.0/(sumbeta_ + sumbeta1_);
	} else { beta = 1.; avebeta = 1.; }
	if(sumbeta1_>0) beta1 = beta1f_*1.0/sumbeta1_; else beta1 = 1.;
}

/*
**  Function : resetstat()
**  Purpose:   reset statistics maintained by the sensor 
*/
void Sensor::resetstat()
{
	unsigned long i;
	Route *cur;
	
	for(i=0; i<=BUFFERSIZE; i++) qlf_[i] = 0;
	for(i=0; i<NUMSTATE; i++) sf_[i] = 0;
	for(i=0; i<=MAXCOMPL; i++) complf_[i] = 0;
	for(i=0; i<=t_->nsens_; i++) hopf_[i] = 0;
			
	msgRX_ = 0L;
	msgTX_ = 0L; 
	msgLOST_ = 0L;
	msgGEN_ = 0L;
	msgDEL_ = 0L;
	
	sumcompl_ = 0L;
	sumhops_ = 0L;
	msgenergy_ = 0.;
		
	alphaf_ = 0L;
	sumalpha_ = 0L;
	alpha1f_ = 0L;
	sumalpha1_ = 0L;
	betaf_ = 0L;
	sumbeta_ = 0L;
	sumbetacond_ = 0L;
	beta1f_ = 0L;
	sumbeta1_ = 0L;
	aveetran = 0.0;
	
	/* reinitialize routes usage */
	for(cur = firstr_; cur != NULL; cur = cur->next_) cur->ntx_ = 0; 
	 
}

/*
**  Purpose:   init of the sink
*/
void Sink::init()
{
	Message* s;
	
	while((s = q_->deque())!=0) Message::free(s);	
	
	pS_ = 0.0;
	pI_ = 1.0;
		
	state_ = ACTIVE_IDLE;
	firstr_ = 0; 
}

/*
**  Function : evolve(long step)
**  Purpose:   evolution of the state of the sensor, probabilistic or deterministic   
**	       the state changes at the beginning of a new step
*/
void Sensor::evolve(unsigned long step) {

	/* update queue length frequency for this step */
	qlf_[q_->length()]++;
	
	/* reset indicators */
	hasTXto_ = id_;
	wantTX_ = 0;
	
	switch (state_) {
	
		case SLEEP: 	
				could_TX_ = 0;
				could_RX_ = 0;
				
				break;
				
		case ACTIVE_IDLE:
		
				could_RX_ = 1;
				could_TX_ = 1;	
				
				if(q_->length() > 0) 
				{
					sumalpha_++;
					sumbeta_++;
					wantTX_ = 1;
				}	
				else sumalpha1_++;	       	       

				break;
				
		case DROWSY_IDLE:
		
				could_RX_ = 0;
				could_TX_ = 1;
				wantTX_ = 1;
				
				sumbeta1_++;
				
				break;
						
		default:	error("state not valid at the beginning of a step");
	}	
}

/*
**  Function : operate(long step)
**  Purpose:   Sensor operation during the step   
*/
void Sensor::operate(unsigned long step) {

	double d;
	
	// if(q_->length() > 0)  printf("Sensor %ld: queue length = %d\n",id_,q_->length()); fflush(stdout);
	
	if(could_TX_ && q_->length() > 0) {
	
		/* try to send a message */
		Route *cur;
		int succeeded = 0;
				
		if(firstr_ == 0) {
		
			printf("Warning! Sensor %ld has no neighbors to forward messages !\n",id_);
			this->lambda_ = 0.0;
			Message::free(q_->deque());
			msgLOST_++;
			t_->nmsgnet()--;
		}	
					
		for(cur = firstr_; cur != NULL && !succeeded; cur = cur->next_) 
		{
			if(cur->N_->could_RX()) {
				succeeded = 1;
				
				Message *m = q_->deque();
				cur->N_->receive(m,this,step);
				
				msgTX_++;
				cur->ntx_++;
				hasTXto_ = cur->N_->id();
				
				if(state_ == ACTIVE_IDLE) {
					state_ = ACTIVE_TX;
					betaf_++; 
				} else if(state_ == DROWSY_IDLE) {
					state_ = DROWSY_TX; 
					beta1f_++;
				} else {
					if(t_->contentionmodel_ == 1) {	
						printf("invio messaggio in stato %d",state_);
						error("state not valid");
					}	
				}	
					
				/* effect of RTS message */
				if(t_->contentionmodel_ == 1) {	
					
					could_TX_ = 0;
					could_RX_ = 0;    
				
					for(Sensor* s = t_->sink_; s != NULL; s = s->next_ )	{
						d = distance(s);
						if (d <= t_->maxdist_) s->could_RX() = 0;
					}
				}									
			}
		}		
	}                        							
}

/*
**  Function : updatestat(long step)
**  Purpose:   updates the statistics of a sensor at the end of a step   
*/
void Sensor::updatestat(unsigned long step) {

	Message* s = 0;
		
	/* update state frequencies */
	sf_[state_]++;
		
	switch (state_) {
	
		case SLEEP: 	
				tauS_--;
				if(tauS_ == 0) {
					state_ = ACTIVE_IDLE;
					aveetran += t_->Esi_;
					tauI_ = RNG::geometric(pIS_);
					// nextarrival_ = RNG::geometric(lambda_);
				}
				
				break;
				
		case ACTIVE_RX:	
		case ACTIVE_TX:				
		case ACTIVE_IDLE:
	
				/* generation of a new message ? */
			        if(lambda_ > 0.) {
		 	               nextarrival_--; 
		 	               if (nextarrival_ == 0) {
			        			       
			        	       // printf("Sensor %ld: generate new message !\n",id_); 
			        	       s = Message::alloc(this); 
			        	       s->stepstart() = step;
			        	       if(q_->length() < BUFFERSIZE) {
			        		       q_->enque(s); 
			        		       msgGEN_++;
			        		       t_->nmsgnet()++;
			        	       } else {
			        		       msgLOST_++;
			        		       printf("Warning !!! buffer overflow at "
			        		       " source %ld : message lost\n", id_);   
			        	       }
			        	       nextarrival_ = RNG::geometric(lambda_);
			               }
			        }
	
				if(tauI_ > 0) tauI_--;
				if(tauI_ == 0) {
					if(q_->length() > 0) {
						state_ = DROWSY_IDLE;
						buftsum_ += q_->length();
						buftnum_ += 1;
					} else {
						state_ = SLEEP;	
						aveetran += t_->Eis_;
						tauS_ = RNG::geometric(pSI_);
					}	
				} else {
					state_ = ACTIVE_IDLE;
				}	
							
				break;
				
		
		case DROWSY_IDLE: break;		
		case DROWSY_TX:
						
				if(q_->length() == 0) {
					state_ = SLEEP;	
					aveetran += t_->Eis_;
					tauS_ = RNG::geometric(pSI_);
				} else {
					state_ = DROWSY_IDLE;	
				}	
				break;
				
	}
}

/*
**  Function : receive(Message* s, Sensor * from, long step)
**  Purpose:   receive a message from Sensor 'from'  
*/
void Sensor::receive(Message *m, Sensor* from, unsigned long step) 
{		
	Sensor *s;
	double d;
	
	printf("Sensor %ld: receive message from %ld\n",id_,from->id()); fflush(stdout);
	
	msgRX_++;
	if(q_->length() == 0) 
		alpha1f_++;
	else
		alphaf_++;

	if(q_->length() < BUFFERSIZE) {
		q_->enque(m); 
		m->nhops()++;
		m->energy() += t_->getenergy(this,from); 
	} else {
		msgLOST_++;
		t_->nmsgnet()--;
		Message::free(m);
		printf("Warning !!! buffer overflow al nodo %ld : message lost\n", id_);
		error("Exiting...");	
	}
	
	if(state_ == ACTIVE_IDLE) 
		state_ = ACTIVE_RX; 
	else {
		if(t_->contentionmodel_ == 1) {	
			printf("receive in state %d , could_RX = %d\n",state_,could_RX_);
			error("State not valid");
		}	
	}	
	
	/* effect of CTS message */
	if(t_->contentionmodel_ == 1) {
		could_RX_ = 0;
		could_TX_ = 0;
		
		for(s = t_->sink_; s != NULL; s = s->next_ )	{
			d = distance(s);
			if (d <= t_->maxdist_) s->could_TX() = 0;
		}
	}		
}

/*
**  Function : receive(Message* m, Sensor * from)
**  Purpose:   Sink reception of a message from Sensor 'from'  
*/
void Sink::receive(Message *m, Sensor* from, unsigned long step) 
{		
	Sensor *s;
	double d;
	
	printf("Sink %ld: receive message from %ld\n",id_,from->id()); fflush(stdout);
	
	msgRX_++;
	if(q_->length() == 0) 
		alpha1f_++;
	else
		alphaf_++;
	
	m->nhops()++;
	m->energy() += t_->getenergy(this,from);
	m->stepend() = step; 
	m->source()->delivered(m); 
	
	t_->nmsgarr()++;
	
	if(state_ == ACTIVE_IDLE) 
		state_ = ACTIVE_RX; 
	else {
		if(t_->contentionmodel_ == 1) error("state not valid");
	}	
	
	/* effect of CTS message */
	if(t_->contentionmodel_ == 1) {
		could_RX_ = 0;
		could_TX_ = 0;
		
		for(s = this->next_; s != NULL; s = s->next_)	{
			d = distance(s);
			if (d <= t_->maxdist_) s->could_TX() = 0;
		}
	}		
	 
	/* free message */
	t_->nmsgnet()--;
	Message::free(m); 
}	

void Sensor::delivered(Message *m)
{
	msgDEL_++;
	msgenergy_ += m->energy();
	unsigned long delay = m->stepend() - m->stepstart();
	if(delay < MAXCOMPL) complf_[delay]++; else complf_[MAXCOMPL]++;
	sumcompl_ += delay;
	sumhops_ += m->nhops();
	hopf_[m->nhops()]++;
	// printf("delay = %ld - nhops = %d\n",delay,m->nhops()); fflush(stdout);
}	

/*
**  Function : insertroute(Sensor* n, double E)
**  Purpose:   insert a new route into the list of ordered routes  
**	       return 1 if a change has occurred in the routing table, 0 otherwise
*/
int Sensor::insertroute(Sensor*n, double E)
{	
	Route *r, *cur;
	
	r = 0;
	
	/* check if sensor n is already in the list */
	for(cur = firstr_; cur != NULL; cur = cur->next_) {
		if (cur->N_ == n) {
			// printf("Sensor %ld : have a route to %ld...",this->id(),n->id());
			if (E < cur->E_) {
				// printf("now it is improved !\n");
				cur->E_ = E;
				if ((cur->prec_ == 0) || (cur->prec_->E_<E)) return(1);
				cur->prec_->next_ = cur->next_;
				r = cur;
			} else 	{
				// printf("e non e' migliorata...\n");
				return(flood_);
			}	
		}
	}
	
	/* create a new Route, if necessary */
	if(r == 0) {
		nr_++;
		if(nr_ > nroutes_) {
			// printf("%ld: Sorry! reached maximum no of routes (%d) routes %ld\n",
			//	this->id(),nroutes_,lastr_->N_->id());
			
			r = lastr_;
			
			/* reuse the last route */
			if(lastr_->prec_) {
				lastr_ = lastr_->prec_;
				lastr_->next_ = 0;
			} 	
			
			nr_--;	
		} else r = new Route;
		
		r->N_ = n;
		r->E_ = E;	
	}	
	
	if(firstr_ == r) return(1);
	
	/* find the next element with respect to the position where to insert the route */ 
	for (cur = firstr_; (cur != 0) && (cur->E_ < E); cur = cur->next_);
	if(cur == firstr_) firstr_ = r;
	if(cur) {
		if (cur->prec_) cur->prec_->next_ = r;
		r->prec_ = cur->prec_;
		cur ->prec_ = r;
		r->next_ = cur;
	} else  {
		r->next_ = 0;
		r->prec_ = lastr_;
		if(lastr_) lastr_->next_ = r;
		lastr_ = r;
	}
	
	// printroutes();
	return(1);
}

/*
**  Function : printroutes()
**  Purpose:   print the routes of a sensor  
*/
void Sensor::printroutes()
{	
	Route *cur;
	int i;
	
	printf("Routing Table of Sensor %ld: (%d entries)\n",this->id(),nr_);
	for(cur = firstr_, i=1; cur != NULL; cur = cur->next_, i++) 
		printf("\tRoute %d: -> sensor %ld - energy %f\n",i,cur->N_->id(),cur->E_);	
}

	
/*
**  Function : update(Sensor* n, double E)
**  Purpose:   Update the routing table using the new route (n,E), setting flood_ to 1 if the 
**             best route has been modified 
*/
void Sensor::update(Sensor*n, double E)
{
	
	Sensor* tmp;
	
	// if(n != 0) printf("Sensor %ld: received this update %ld - %f\n",this->id(),n->id(),E);
	// fflush(stdout);
	
	/* discard routes referring to paths containing this sensor */
	for(tmp = n; tmp != 0 && tmp != this; tmp = tmp->nexthop());
	if(tmp == this) {
		// printf("%ld : this route goes to the same sensor !\n",this->id());
		return; 
	}	
	
	if (nr_ == 0) {
		firstr_ = new Route;
		firstr_->N_ = n;
		firstr_->E_ = E;
		firstr_->next_ = 0;
		firstr_->prec_ = 0;
		lastr_ = firstr_;
		nr_ = 1;
		flood_ = 1;
		// printf("sensor %ld : main route !\n",this->id());
	} else if (E < this->bestE()) {
		// printf("sensor %ld : found better route !\n",this->id());
		flood_ = insertroute(n,E);
	} else if ((E <= this->worstE()) || (nr_ < nroutes_)) {
		flood_ = insertroute(n,E);
	} else { 
		// printf("sorry: not an useful update\n");	
	}
}		

	
	
	
	

