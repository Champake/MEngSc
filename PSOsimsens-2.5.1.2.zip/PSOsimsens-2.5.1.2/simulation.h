/*
**  File:        simulation.h
**  Program:     Sensor 
**  Purpose:     class simulation      
**  Author:      Michele Garetto / Dario Panno
**  Last Update: January 21 2003
*/


#ifndef simulation_h
#define simulation_h

#include "sensor.h"
#include "topology.h"
#include "message.h"
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_poly.h>

#define BUFSIZE 50


class Simulation {

public:

	Simulation(Topology* t) { t_ = t; }
	
	inline int& simtype() { return(simtype_); }

	void execute();
	void inputparameters();
	void printresults_single();
	void printresults_multi();
			
protected:

	int simtype_;		        /* 1: single message - 2: multiple messages */
	unsigned long nsimrun_;		/* number of simulation experiments */
	unsigned long step_;		/* time step */
	unsigned long resetstep_;	/* reset time step */
	unsigned long nmsgstop_;	/* number of messages arrived at the sink to stop simulation */
	unsigned long nmsgreset_;	/* number of messages arrived at the sink to reset statistics */
	unsigned long nmsgmax_;	 	/* maximum number of messages in the network to prevent instability */
	
	Topology* t_;		/* associated topology */
	char name_[MAXCAR];	/* simulation name (used to print out results) */
	
};

#endif

	
