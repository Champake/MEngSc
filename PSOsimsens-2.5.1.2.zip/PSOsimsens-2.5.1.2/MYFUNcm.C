/*
  This procedure contains the optimization functions
  Yuhui Shi, May 15, 1998
  Civil & Opti Channel added by C Mendis, 15 March 2005
*/

#include "headfile.h"
#include "extern.h"
#include "myfun.h"

float f6(int a)
{
/*
	This is the f6 function as described in the Handbook of
	Genetic Algorithms, p.8
*/
	double num, denom, f6;
	double errorf6;

	num=(sin(sqrt((xx[0][a]*xx[0][a])+(xx[1][a]*xx[1][a]))))  *
		 (sin(sqrt((xx[0][a]*xx[0][a])+(xx[1][a]*xx[1][a])))) - 0.5;
	denom=(1.0 + 0.001 * ((xx[0][a] * xx[0][a]) + (xx[1][a]*xx[1][a]))) *
		(1.0 + 0.001 * ((xx[0][a] * xx[0][a]) + (xx[1][a]*xx[1][a])));
	f6=(double) 0.5 - (num/denom);
	errorf6=1 - f6;
	return errorf6;
}

float sphere(int a, int b)
{
	/* This is the familiar sphere model
		int a: index of particles   b:dimension */

	double result;
	int i;

	result=0.0;

	for (i=0;i<b;i++)
	{
		result += xx[i][a]*xx[i][a];
	}

	return result;
}

float rosenbrock(int a, int b)
{
	/* this is the Rosenbrock function
		a: index of the particles; b:dimension */

	int i;
	double result;

	result=0.0;

	for (i=1;i<b;i++)
	{
		result +=100.0*(xx[i][a]-xx[i-1][a]*xx[i-1][a])*(xx[i][a]-xx[i-1][a]*xx[i-1][a]) + (xx[i-1][a]-1)*(xx[i-1][a]-1);
	}

	return fabs(result);
}

float rastrigrin(int a, int b)
{
	/* This is the generalized Rastrigrin function
		a:index of the particles; b:dimension */

	int i;
	double result;

	result=0.0;

	for (i=0;i<b;i++)
	{
		result +=xx[i][a]*xx[i][a] - 10.0*cos(2.0*3.141591*xx[i][a])+10.0;
	}

	return result;
}

float griewank(int a,int b)
{
	/* This is the generalized Griewank function
		a:index of the particles; b:dimension */

	int i;
	double result_s,result_p;

	result_s=0.0;
	result_p=1.0;

	for (i=0;i<b;i++)
	{
		result_s +=xx[i][a]*xx[i][a];
		result_p *=cos(xx[i][a]/sqrt(i+1));
	}
	result_s =result_s/4000.0 - result_p +1;

	return result_s;
}

float civil(int a, int b)
{
        /* This is the familiar Structural Characteristic Function
                int a: index of particles   b:dimension */

        const k = 5e+6,m = 1000,pi=3.141591;
        float alpha;
        double result;

        int i;

        alpha = k/(4*m*pi^2);
        result=0.0;

        for (i=0;i<b;i++)
        {
        result = pow(xx[i][a],6)-5*pow(alpha*xx[i][a],4)+6*pow(alpha,2)*pow(xx[i][a],2)-pow(alpha,3);
        }
        return result;
}

float opchannel(int a)
{
        /* This is a Channel Optimization Function tested in MATLAB
                int a: index of particles   b:dimension */

        const k = 5e+6,m = 1000,pi=3.141591;
        float alpha;
        double result,err0;

        result=0.0;

        result = 200/xx[1][a] - xx[1][a]/tan(xx[0][a]) + 2*xx[1][a]/sin(xx[0][a]);
        err0=1 - result;
        return result;
}


/*
  This section contains the Utility functions
  added by C Mendis, 15 March 2005
*/

float nMin(float num1, float num2)
{
  /* This is the minimum deriving Function */

    float noMin;
    if (num1>num2)
        noMin=num2;
    else
        noMin=num1;
    return noMin;
}

int nSign(float num)
{
  /* This is the Sign deriving Function */

    int noMin;
    if (num>0)
        noMin=1;
    else
        {
        if (num!=0)
        noMin=-1;
        else
        noMin=0;
        }
    return noMin;
}
