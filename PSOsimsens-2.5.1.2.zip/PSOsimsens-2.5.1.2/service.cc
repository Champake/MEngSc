/*
**  File:        service.cc
**  Program:     Sensor 
**  Purpose:     service routines    
**  Author:      Michele Garetto
**  Last Update: November 11 2002
*/

#include <string.h>
#include "service.h"
#include "sensor.h"

int get_int()
{
    static char linebuffer[255];
    char* pin;
    int var;
    do{
        fgets(linebuffer, 255, stdin);      /*  Gets a data from stdin without flushing problems */
        pin = strrchr (linebuffer, '\n');                  
        if (pin!=NULL) *pin = '\0';
    } while( *linebuffer=='#' || (*linebuffer=='/' && *(linebuffer+1)=='/') || *linebuffer=='\0');
    sscanf(linebuffer,"%d",&var);
    return(var); 
}

unsigned long get_long()
{
    static char linebuffer[255];
    char* pin;
    unsigned long var;
    do{
        fgets(linebuffer, 255, stdin);      /*  Gets a data from stdin without flushing problems */
        pin = strrchr (linebuffer, '\n');                  
        if (pin!=NULL) *pin = '\0';
    } while( *linebuffer=='#' || (*linebuffer=='/' && *(linebuffer+1)=='/') || *linebuffer=='\0');
    sscanf(linebuffer,"%ld",&var);
    return(var); 
}

double get_double()
{
    static char linebuffer[255];
    char* pin;
    double var;
    do{
        fgets(linebuffer, 255, stdin);      /*  Gets a data from stdin without flushing problems */
        pin = strrchr (linebuffer, '\n');                  
        if (pin!=NULL) *pin = '\0';
    } while( *linebuffer=='#' || (*linebuffer=='/' && *(linebuffer+1)=='/') || *linebuffer=='\0');
    sscanf(linebuffer,"%lf",&var);
    return(var); 
}

void get_string(char *s)
{
    static char linebuffer[255];
    char* pin;
    do{
        fgets(linebuffer, 255, stdin);      /*  Gets a data from stdin without flushing problems */
        pin = strrchr (linebuffer, '\n');                  
        if (pin!=NULL) *pin = '\0';
    } while( *linebuffer=='#' || (*linebuffer=='/' && *(linebuffer+1)=='/') || *linebuffer=='\0');
    sscanf(linebuffer,"%s",s);
}

void error(char*s)
{
  printf("Error : %s\n",s);
  exit(1);
}

void RNG::inputseed() {

  unsigned long int seed_;	/* Random number generator seed */
  
  printf("Random number generator seed: ");
  seed_ = get_long();
  printf("%ld\n",seed_);
  if (seed_ > 0L) gsl_rng_set(rng_,seed_);
  
}



